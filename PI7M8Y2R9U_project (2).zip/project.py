import random

options = ["rock", "paper", "scissors"]

print("Welcome to Rock-Paper-Scissors Game!")

while True:
    user = input("Enter rock(✊), paper(🤚) or scissors(✌️) (or 'quit' to stop): ").lower()

    if user == "quit":
        print("Thanks for playing!❤️")
        break

    if user not in options:
        print("🚨Invalid choice, try again.\n")
        continue

    computer = random.choice(options)
    print("Computer chose:", computer)

    if user == computer:
        print("Result: It's a tie!😑\n")
    elif (user == "rock" and computer == "scissors") or \
         (user == "paper" and computer == "rock") or \
         (user == "scissors" and computer == "paper"):
        print("Result: You win!☺️\n")
    else:
        print("Result: You lose!🥺\n")